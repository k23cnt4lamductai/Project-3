package K23CNT3_LamDucTai_WebBanDienThoai;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class K23Cnt3LamDucTai2310900092WebBanDienThoaiApplication {

	public static void main(String[] args) {
		SpringApplication.run(K23Cnt3LamDucTai2310900092WebBanDienThoaiApplication.class, args);
        System.out.println("Hi Tài");
	}

}
