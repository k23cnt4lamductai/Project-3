package K23CNT3_LamDucTai_WebBanDienThoai.repository;

import K23CNT3_LamDucTai_WebBanDienThoai.entity.LdtChiTietHoaDon;
import org.springframework.data.jpa.repository.JpaRepository;

public interface LdtChiTietHoaDonRepository extends JpaRepository<LdtChiTietHoaDon, Integer> {
}