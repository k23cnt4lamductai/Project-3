package K23CNT3_LamDucTai_WebBanDienThoai.repository;

import K23CNT3_LamDucTai_WebBanDienThoai.entity.LdtDanhMucSP;
import org.springframework.data.jpa.repository.JpaRepository;

public interface LdtDanhMucSPRepository extends JpaRepository<LdtDanhMucSP, Integer> {
}