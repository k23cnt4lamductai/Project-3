package K23CNT3_LamDucTai_WebBanDienThoai.repository;

import K23CNT3_LamDucTai_WebBanDienThoai.entity.LdtHoaDon;
import org.springframework.data.jpa.repository.JpaRepository;

public interface LdtHoaDonRepository extends JpaRepository<LdtHoaDon, Integer> {
}