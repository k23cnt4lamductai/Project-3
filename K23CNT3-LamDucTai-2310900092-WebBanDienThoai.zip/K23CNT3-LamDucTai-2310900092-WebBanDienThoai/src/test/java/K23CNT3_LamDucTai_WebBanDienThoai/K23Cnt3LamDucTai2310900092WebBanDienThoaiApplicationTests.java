package K23CNT3_LamDucTai_WebBanDienThoai;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class K23Cnt3LamDucTai2310900092WebBanDienThoaiApplicationTests {

	@Test
	void contextLoads() {
	}

}
